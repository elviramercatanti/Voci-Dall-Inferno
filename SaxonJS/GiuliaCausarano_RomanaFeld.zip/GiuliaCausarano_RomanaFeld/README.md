# Progetto-di-laurea
Trascrizione e codifica testimonianza. 
Schema di codifica utilizzato: Moduli TEI di base + msdescription,trans,analysis,linking,namesdates,verse.
