# Codifica-Testimonianze-Orali-Arminio-Wachsberger
Codifica di due testimonianze orali di Arminio Wachsberger, sopravvissuto ai campi di sterminio.

# Applicazione-JavaScript-SaxonJS
Applicazione Javascript-SaxonJS che permette la visualizzazione e l'interrogazione delle trascrizioni.

# Tesi-Informatica-Umanistica
Lavoro realizzato per la tesi di Laurea Triennale in Informatica Umanistica (Università di Pisa), nell'ambito del progetto di ricerca Voci dall'Inferno.
